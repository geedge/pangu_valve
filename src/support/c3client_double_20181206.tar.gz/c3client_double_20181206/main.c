#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <ctype.h>

#include <getopt.h>
#include "grule.h"
#include "ruleread.h"
#define CCC_MAX_SIZE 16

void print_help()
{
        printf("Usage: c3client -a authdata -s serverlist -c rule_file [vh]\n");
	printf("  -a,--auth                      authdata\n");
	printf("  -s,--server                    server list\n");
	printf("  -c,--conf                      rule files\n");
        printf("  -v                             print version\n");
        printf("  -h,--help                      print help message\n");
}


uint8_t char2binary(char c)
{
	if(c >= 'a' &&  c <= 'f'){
		return 10 + c - 'a';
	}else if(c >= '0' && c <= '9'){
		return c - '0';
	}
	return 0;
}


char* auth2str(const uint8_t *authdata, char * buf)
{

	sprintf(buf, "%02x%02x%02x%02x%02x%02x%02x%02x", authdata[0], authdata[1], authdata[2], 
		authdata[3], authdata[4], authdata[5], authdata[6], authdata[7]);
	return buf;
}


int auth_str2binary(const char * str, uint8_t *auth_data)
{
	uint8_t a, b;

	int i;

	for(i = 0; i < 8; i++){
		a = (uint8_t)str[i * 2];
		b = (uint8_t)str[i * 2 + 1];

		if(isxdigit(a) && isxdigit(b)){
			auth_data[i] = char2binary(tolower(a)) * 16 + char2binary(tolower(b));
		}else{
			return -1;
		}
		
	}
	return 0;
}


int grule_service(int argc, char ** argv)
{
	grule_hdl_t handle;
	//const char *ccc_list = "192.168.0.162:15000"; //it should be inited.
	//const char *ccc_list = "10.174.192.19:10007"; //it should be inited.
	char ccc_list[1024];
	char file_path[2048];
	//char [];
	size_t      ccc_num = 8; 
	size_t      ccc_index = 0;
	int         state;
	uint8_t     auth_data[8]; // it should be inited
	int         ret;
	size_t      auth_err_num;
	size_t      i;
	int c;

	grule2_t          rule_list[16];
	grule_result_t   rst_list[16];
	uint64_t         rule_num;
	rulereader_t *rr;
	char buf[65536];

	rulevec_t rv[16];

	#define SERVICE_STATE_IDLE         1
	#define SERVICE_STATE_FIRSTCONNECT 2
	#define SERVICE_STATE_CONNECTED    3
	//#define SERVICE_STATE_

	state        = SERVICE_STATE_IDLE;
	auth_err_num = 0;
	handle       = NULL;

	if(argc <= 1){
		fprintf(stderr, "no rule file, exiting\n");
		print_help();
		exit(-1);
	}

	memset(ccc_list, 0, sizeof(ccc_list));
	memset(file_path, 0, sizeof(file_path));
	memset(auth_data, 0, sizeof(auth_data));
	
	int option_index = 0;
        struct option long_options[] = { 
             {"version", 0, 0, 'v'},
             {"help",0,0,'h'},
	     {"conf",1, 0, 'c'},
	     {"server", 1, 0, 's'},
	     {"auth", 1, 0, 'a'},
             {0, 0, 0, 0}
        };  



	while (1) {
                //int this_option_optind = optind ? optind : 1;
                c = getopt_long (argc, argv, "c:a:s:vh",
                long_options, &option_index);
                if (c == -1) 
                        break;

                switch (c) {

			case 'c':
				if(strlen(optarg) > sizeof(file_path) - 1){
					fprintf(stderr, "-c config err: %s\n", optarg);
					return -1;
				}
				strcpy(file_path, optarg);
				break;
			case 'a':
				if(strlen(optarg) != 16){
					fprintf(stderr, "bad authdata: %s\n", optarg);
					return -1;
				}

				if(auth_str2binary(optarg, auth_data) < 0){
					fprintf(stderr, "bad authdata: %s\n", optarg);
					return -1;
				}
				break;
			case 's':
				if(strlen(optarg) > sizeof(ccc_list) - 1){
					fprintf(stderr, "bad server: %s\n", optarg);
					return -1;
				}
				strcpy(ccc_list, optarg);
				break;
                        case 'h':
                                print_help();
                                //return -1;
                                return 0;
                                //break;
                        case 'v':
                                //printf ("option c with value '%s'\n", optarg);
                                printf("program version : \033[32m%s\033[0m\n",  PROGRAM_DATE);
                                return 0;
                                //break;
                         default:
                                printf ("?? getopt returned character code 0%o ??\n", c); 
                                print_help();
                                return -1; 
                                break;
                }   
        }   


	printf("----config");
	printf("authdata:  %s\n", auth2str(auth_data, buf));
	printf("ccc_serv:  %s\n", ccc_list);
	printf("conf_path: %s\n", file_path);

	

	char *argv2[5];

	argv2[0] = file_path;
	rr = rulereader_init(argv2, 1);

	
	

	handle = grule_open();

	if(handle == NULL){
		fprintf(stderr, "grule lib error\n");
		abort();
	}

	grule_opt_set(handle, GRULE_SOL_PROTO, GRULE_TYPE_AUTH, auth_data, sizeof(auth_data));

	ret = grule_connect(handle, ccc_list);

	if(ret != 0){
		fprintf(stderr, "addr error\n");
		abort();
	}

	while(1){

			switch(state){
				case SERVICE_STATE_IDLE:
					/*handle = grule_open();
					if(handle == NULL){
						fprintf(stderr, "grule lib error\n");
						abort();
					}
					grule_opt_set(handle, GRULE_SOL_PROTO, GRULE_TYPE_AUTH, auth_data, sizeof(auth_data));
					ret = grule_connect(handle, ccc_list);
					ccc_index = (ccc_index + 1) % ccc_num;*/
					/*while(grule_app_status(handle) != GRULE_APP_STATUS_CONNECTED){
						sleep(1);
					}*/

					/*if(ret == 0){
						state = SERVICE_STATE_FIRSTCONNECT;
						auth_err_num = 0;
						continue;
					}
					
					if(grule_errno(handle) == GRULE_ERRNO_AUTH){
						auth_err_num++;
						if(auth_err_num >= ccc_num){
							fprintf(stderr, "auth error\n");
							abort();
						}
						//  stop the program if trying many times
					}else{
						fprintf(stderr, "connect error: %s\n", grule_error_str(grule_errno(handle)));
					}*/
					//goto _error;
					state = SERVICE_STATE_FIRSTCONNECT;
					break;
				case SERVICE_STATE_FIRSTCONNECT:
					// if having durable rules, send all of them.
					state = SERVICE_STATE_CONNECTED;
					break;
					//break;
				case SERVICE_STATE_CONNECTED:
					//
					while(1){
						// has rule?????
						
						memset(rule_list, 0, sizeof(rule_list));
						// init
						// set rule;
						// sending
						/*rule_list[0].rule_id = 1;
						rule_list[0].srv_type = 5;
						rule_list[0].rule_scope = 1000;
						rule_list[0].big_type = GRULE_BIG_TYPE_SIMPLE4;
						rule_list[0].durable = 0;
						rule_list[0].action = 1;
						rule_list[0].rule_type.grule_type = 0;
						rule_list[0].rule_type.sip_flag  = 1;
						//rule_list[0]. = ;
						rule_list[0].s4.sip = inet_addr("1.2.3.4");*/

						memset(&rule_list[0], 0, sizeof(grule2_t));
						ret = rulereader_readnext(rr, &rule_list[0]);
						if(ret != 0){
							fprintf(stderr, "end, exit..\n");
							//exit(0);
							while(1) sleep(1);
						}
						//parse_rule(&rule_list[0]);


						size_t size;

						size = sizeof(buf);

						printf("---%s\n", parse_rule2_str_full(&rule_list[0], buf, &size));
					
						while(1){
							rv[0].rvec_base = &rule_list[0];
							rv[0].rvec_size = sizeof(grule2_t);
							rv[0].rule_ver = RULE_VERSION_TUPLE6;
							//ret = grule_send(handle, rule_list, 1, 0);
							ret = grule_sendmsg(handle, rv, 1, 0);
							//et = 1;
							if(ret < 0){
								fprintf(stderr, "sending error: %s\n", grule_error_str(grule_errno(handle)));
								//goto _error;
								break;
							}else if(ret == 0){
								usleep(20);
								continue;
							}
							usleep(100);

							break;
						}

						//while(1){
						//sleep(1);
						//}

						/*ret = grule_recv(handle, rst_list, rule_num, 0);
						if(ret != rule_num){
							fprintf(stderr, "recv error: %s\n", grule_error_str(grule_errno(handle)));
							goto _error;
						}

						for(i = 0; i < rule_num; i++){
							if(rst_list[i].result != GRULE_RESP_OK && rst_list[i].result != GRULE_RESP_WHITELIST){ // rule is wrong.
								fprintf(stderr, "rulerror: %s\n", grule_bad_results_str(&rst_list[i]));
								abort();// fatal error.
							}
						}*/
					}
					break;
				default:
					fprintf(stderr, "bad state: %d\n", state);
					abort();
					break;
			}	
		_noerror:
			continue;
		_error:
			if(handle != NULL){
				//grule_close(handle);
			}
			sleep(2);
			state = SERVICE_STATE_IDLE;

	}
}



__attribute__((weak)) int main(int argc, char ** argv)
{

#if 0
	rulereader_t * rr;
	int ret;
	grule_t rule;
	rr = rulereader_init(++argv, argc - 1);

	while(1){

		ret = rulereader_readnext(rr, &rule);
		if(ret != 0){
			break;
		}
		parse_rule(&rule);
	}
	return 0;
#endif
	grule_service(argc , argv);

		

	// rr = rulereader_init(argv, argc);
}


