#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "grule.h"



int main(int argc, char ** argv)
{
	char src_buf[1024];
	char dst_buf[1024];
	grule_t src;
	grule_t dst;
	size_t src_len, dst_len;


	memset(&src, 0, sizeof(src));
	memset(&dst, 0, sizeof(dst));


	src.rule_id = 0;
	src.srv_type = 10;
	src.rule_scope = 10;
	src.big_type = GRULE_BIG_TYPE_MASK4;
	src.durable = 1;
	src.action = 1;
	src.rule_type.sip_flag = 1;
	src.rule_type.sipmsk_flag = 1;
	src.rule_type.dip_flag = 1;
	src.rule_type.dipmsk_flag = 1;
	src.rule_type.proto_flag = 1;
	src.rule_type.pmsk_flag = 1;
	
	src.m4.sip = 1;
	src.m4.sip_mask = 0xffffffff;
	src.m4.dip = 2;
	src.m4.dip_mask = 0xffffffff;
	src.m4.proto = 3;
	src.m4.proto_mask = 0xff;

	grule_mask2flexible(&src, &dst);

	src_len = sizeof(src_buf);
	dst_len = sizeof(dst_buf);

	printf("src_rule: %s\ndst_rule: %s\n",
		parse_rule_str_full(&src, src_buf, &src_len),
		parse_rule_str_full(&dst, dst_buf, &dst_len));

	return 0;




}
